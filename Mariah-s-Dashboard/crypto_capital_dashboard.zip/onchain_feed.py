import requests
def get_eth_gas():
    return {"low": 14, "avg": 21, "high": 32}

def get_block_info():
    return 19876543
