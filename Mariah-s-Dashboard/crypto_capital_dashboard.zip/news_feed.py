def get_crypto_news():
    return [{"title": "BTC pumps 10% on ETF approval", "url": "#", "published": "Now", "source": "CoinDesk"}]
